<?php   

function xmldb_assignment_random_upgrade($oldversion) {
    global $CFG, $DB, $OUTPUT;
  
    if ($oldversion < 2008081900) {

        /////////////////////////////////////
        /// new file storage upgrade code ///
        /////////////////////////////////////

        $fs = get_file_storage();

        $sqlfrom = "FROM {assignment} a
                    JOIN {modules} m ON m.name = 'assignment'
                    JOIN {course_modules} cm ON (cm.module = m.id AND cm.instance = a.id)
                    WHERE assignmenttype = 'random'";
        
        $count = $DB->count_records_sql("SELECT COUNT('x') $sqlfrom");

        $rs = $DB->get_recordset_sql("SELECT a.id, a.course, a.var1, a.var2, cm.id AS cmid $sqlfrom ORDER BY a.course");

        if ($rs->valid()) {
            $pbar = new progress_bar('migrateassignmentfiles', 500, true);
            $i = 0;
            foreach ($rs as $random) {
                $i++;
                upgrade_set_timeout(180); // set up timeout, may also abort execution
                $pbar->update($i, $count, "Migrating assignment submissions - $i/$count.");

                // migrate assignment files - begin 
                $basepath = "$CFG->dataroot/$random->course/$CFG->moddata/random/assignment/$random->var1/";
                if (!file_exists($basepath)) {
                    //no files
                    continue;
                }
                $context = get_context_instance(CONTEXT_MODULE, $random->cmid);

                // migrate submitted files first
                $path = $basepath;
                $items = new DirectoryIterator($path);
                foreach ($items as $item) {
                    if (!$item->isFile()) {
                        continue;
                    }
                    if (!$item->isReadable()) {
                        echo $OUTPUT->notification(" File not readable, skipping: ".$path.$item->getFilename());
                        continue;
                    }  
                    $filename = clean_param($item->getFilename(), PARAM_FILE);
                    if ($filename === '') {
                        continue;
                    }
                    if (!$fs->file_exists($context->id, 'mod_assignment', 'inputfiles', $random->id, '/', $filename)) {
                        $random->id = 0;  // zisti preco je itemid rovne 0 v pripade random ???
                        $file_record = array('contextid'=>$context->id, 'component'=>'mod_assignment', 'filearea'=>'inputfiles', 'itemid'=>$random->id, 'filepath'=>'/', 'filename'=>$filename, 'userid'=>$random->userid);
                        if ($fs->create_file_from_pathname($file_record, $path.$item->getFilename())) {
                            unlink($path.$item->getFilename());
                        }
                    }
                }
                unset($items); //release file handles
                // remove dirs if empty
                //echo "var1 = $CFG->dataroot/$random->course/$CFG->moddata/random/assignment/$random->var1 <br />";
                @rmdir("$CFG->dataroot/$random->course/$CFG->moddata/random/assignment/$random->var1");
                // migrate assignment files - end 

                // migrate solution files - begin                 
                $basepath = "$CFG->dataroot/$random->course/$CFG->moddata/random/solution/$random->var2/";
                if (!file_exists($basepath)) {
                    //no files
                    continue;
                }
                $context = get_context_instance(CONTEXT_MODULE, $random->cmid);

                // migrate submitted files first
                $path = $basepath;
                $items = new DirectoryIterator($path);
                foreach ($items as $item) {
                    if (!$item->isFile()) {
                        continue;
                    }
                    if (!$item->isReadable()) {
                        echo $OUTPUT->notification(" File not readable, skipping: ".$path.$item->getFilename());
                        continue;
                    }  
                    $filename = clean_param($item->getFilename(), PARAM_FILE);
                    if ($filename === '') {
                        continue;
                    }
                    if (!$fs->file_exists($context->id, 'mod_assignment', 'outputfiles', $random->id, '/', $filename)) {
                        $random->id = 0;  // zisti preco je itemid rovne 0 v pripade random ???
                        $file_record = array('contextid'=>$context->id, 'component'=>'mod_assignment', 'filearea'=>'outputfiles', 'itemid'=>$random->id, 'filepath'=>'/', 'filename'=>$filename, 'userid'=>$random->userid);
                        if ($fs->create_file_from_pathname($file_record, $path.$item->getFilename())) {
                            unlink($path.$item->getFilename());
                        }
                    }
                }
                unset($items); //release file handles
                // remove dirs if empty
                //echo "var2 = $CFG->dataroot/$random->course/$CFG->moddata/random/solution/$random->var2 <br />";
                @rmdir("$CFG->dataroot/$random->course/$CFG->moddata/random/solution/$random->var2");
                // migrate solution files - end                 
            }
            //echo "assignment = $CFG->dataroot/$random->course/$CFG->moddata/random/assignment <br />";
            //echo "solution = $CFG->dataroot/$random->course/$CFG->moddata/random/solution <br />";
            @rmdir("$CFG->dataroot/$random->course/$CFG->moddata/random/assignment");
            @rmdir("$CFG->dataroot/$random->course/$CFG->moddata/random/solution");
            @rmdir("$CFG->dataroot/$random->course/$CFG->moddata/random");
        }
        $rs->close();

        upgrade_mod_savepoint(true, 2009042002, 'assignment'); // tu neviem aake ma byt cislo     

    } 

    return true;
}
 
?>