This is a development version for M2.0. Please DO NOT use it in
production server. It can contain serious bugs. 

This version is fairly complete. What is still missing is upgrade from
M1.9 version. After upgrade of M1.9 to M2.0, each random assignment
does not contain its files. However, if these are copied into it, it
should work as before.

==================================================================
Random assignment (implemented for Moodle 2, tested with 2.0.1)

Random assignment is an attempt to handle larger classes of students.
For this purpose, we generate a series of html (txt, pdf) files with the
same structure but different numbers. In addition, we generate
corresponding files with hints to solutions for teachers.

Random assignment is a plugin for assignments with following
properties:

- It is derived from Asignment: Advanced uploading of files. It shares
  all its features. 

- Teacher specifies one or more files for
  assignments and (optionally) solution files with the same names

- Each student gets one of these files randomly 

- In the assignment feedback page, teacher sees the assignment file
  and optionally the solution file as well.

Installation procedure:

1. Copy directory random/ to moodle/mod/assignment/type/
2. If needed, add your language. Language files are located in 
   moodle/mod/assignment/type/random/lang

Upgrade from Moodle 1.x to Moodle 2.0
File upgrade.php replaces file mod/assignment/db/upgrade.php
The upgrade code is located at the end of the original file


Creation of an assignment:

1. Create activity: Assignment: random assignment and specify files for assignments and solutions.

Student sees link to the assignment and, optionally its content if it
is a html or txt file (utf-8 encoded). Teacher sees links to both files when grading 
a student on the feedback page. Teacher also sees links to all files 
on the assignment and feedback pages.


miroslav.fikar[at]gmail.com
lubos.cirka[at]stuba.sk
March 2011

Citation:
@inproceedings{vu2007,
  author 	 =  	{Cirka, L. and Fikar, M.},
  title 	 =  	{LMS Moodle - Random Assignment},
  booktitle 	 =  	{Proc. of 8th International Conference Virtual university 2007},
  year 	 =  	{2007},
  pages 	 =  	{168-170},
  editor 	 =  	{Huba, M.},
  address 	 =  	{Bratislava},
  month 	 =  	{December 13 - 14},
  annote 	 =  	{The aim of this paper is to describe the new assignment type - random assignment. The plugin Random text for module Assignment is a Moodle activity add-on for uploads to each assignment several files for students and possibly files for instructors with solutions.}
}

<a href="http://www.kirp.chtf.stuba.sk/publicatione_info.php?id_pub=433">Full paper [PDF]</a>
