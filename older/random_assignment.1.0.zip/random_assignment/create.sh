#! /bin/bash
MDIR=/home/www/moodle
MDDIR=/home/moodledata

cp -r random/ $MDIR/mod/assignment/type/
cp -f $MDIR/lang/en_utf8/assignment.php .
sed -i '/?>/d' assignment.php
cat assignment.php lang/en_utf8/random_assignment.php end.php > en_assignment.php
cp -f $MDDIR/lang/sk_utf8/assignment.php .
sed -i '/?>/d' assignment.php
cat assignment.php lang/sk_utf8/random_assignment.php end.php > sk_assignment.php

cp -f en_assignment.php $MDIR/lang/en_utf8/assignment.php
cp -f sk_assignment.php $MDDIR/lang/sk_utf8/assignment.php

mv $MDIR/file.php $MDIR/file.php.old
cp file.php $MDIR/file.php

rm -f en_assignment.php sk_assignment.php assignment.php
