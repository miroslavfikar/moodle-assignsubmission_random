<?php // $Id: assignment.class.php,v 1.30.2.2 2007/08/06 13:26:44 poltawski Exp $

/**
 * Extend the base assignment class for assignments where you upload a single file
 *
 */
class assignment_random extends assignment_base {
    

    function print_student_answer($userid, $return=false){
           global $CFG, $USER;
       
        $filearea = $this->file_area_name($userid);

        $output = '';
    
        if ($basedir = $this->file_area($userid)) {
            if ($files = get_directory_list($basedir)) {
                
                foreach ($files as $key => $file) {
                    require_once($CFG->libdir.'/filelib.php');
                    
                    $icon = mimeinfo('icon', $file);
                    if ($CFG->slasharguments) {
                        $ffurl = "$CFG->wwwroot/file.php/$filearea/$file";
                    } else {
                        $ffurl = "$CFG->wwwroot/file.php?file=/$filearea/$file";
                    }
                    //died right here
                    //require_once($ffurl);                
                    $output = '<img align="middle" src="'.$CFG->pixpath.'/f/'.$icon.'" class="icon" alt="'.$icon.'" />'.
                            '<a href="'.$ffurl.'" >'.$file.'</a><br />';
                }
            }
        }

        $output = '<div class="files">'.$output.'</div>';
        return $output;    
    }

    function assignment_uploadsingle($cmid=0) {
        parent::assignment_base($cmid);

    }

	// -------------------------------------------
	// Random assignment begin
	// -------------------------------------------

	function custom_feedbackform($submission, $return=false) {
		global $CFG, $COURSE;
		$sql = "SELECT * FROM {$CFG->prefix}assignment_submissions WHERE assignment='".$this->assignment->id."' AND userid='".$submission->userid."'";
		$record = get_record_sql($sql);

		$link1 = "<a href='".$CFG->wwwroot."/file.php/".$COURSE->id."/moddata/random/assignment/".$this->assignment->var1."/".$record->data1."' target='_blank'>".$record->data1."</a><br />\n";
		$link2 = "<a href='".$CFG->wwwroot."/file.php/".$COURSE->id."/moddata/random/solution/".$this->assignment->var2."/".$record->data1."' target='_blank'>".$record->data1."</a><br />\n";
		$output = "<p>\n";
		if(file_exists($CFG->dataroot.'/'.$COURSE->id.'/moddata/random/assignment/'.$this->assignment->var1."/".$record->data1))
			$output .= get_string('responsefilesassignment', 'assignment').$link1;
		if(file_exists($CFG->dataroot.'/'.$COURSE->id.'/moddata/random/solution/'.$this->assignment->var2."/".$record->data1))
			$output .= get_string('responsefilessolution', 'assignment').$link2;
		$output .= "</p>\n";
		return $output;
	}

	// funkcia zobrazujuca zadanie
    function view() {
        global $USER, $CFG, $COURSE;
        
		// vyzaduje prihlasenie
        $context = get_context_instance(CONTEXT_MODULE,$this->cm->id);
        require_capability('mod/assignment:view', $context);
        
        add_to_log($this->course->id, "assignment", "view", "view.php?id={$this->cm->id}", $this->assignment->id, $this->cm->id);

        $this->view_header();

		// zobrazuje opis zadania, ak nie je prazdny (prazdny uplne nie je, vzdy tam ostavaju <p> a </p>
		if(trim(str_replace("<p>","",str_replace("</p>","",$this->assignment->description))))
			$this->view_intro();

		// -----------------------------------------------------------------------------------------------------------------
		// ak je prilaseny ucitel
		if(has_capability('mod/assignment:grade', $context)) {

			$error1 = array();
			if($this->assignment->var1) {
				$fullpath = $CFG->dataroot.'/'.$COURSE->id.'/moddata/random/assignment/'.$this->assignment->var1;
				$file_array_1 = array();
				$directory = opendir($fullpath); 
				while (false !== ($file = readdir($directory))) {
					if ($file == "." || $file == "..")
						continue;
					else
						$file_array_1[] = $file; // zoznam vsetkych suborov v adresari zadani (vlozeny do pola)
				}
				closedir($directory);
			}
			else
				$error1[] .= get_string('problemdirectoryassignment',"assignment");
			if(!count($file_array_1))
			$error1[] .= get_string('problemfileassignment',"assignment");

			$error2 = array();
			if($this->assignment->var2) {
				$fullpath = $CFG->dataroot.'/'.$COURSE->id.'/moddata/random/solution/'.$this->assignment->var2;
				$file_array_2 = array();
				$directory = opendir($fullpath); 
				while (false !== ($file = readdir($directory))) {
					if ($file == "." || $file == "..")
						continue;
					else
						$file_array_2[] = $file; // zoznam vsetkych suborov v adresari vysledkov (vlozeny do pola)
				}
				closedir($directory);
			}
			else
				$error2[] .= get_string('problemdirectorysolution',"assignment");
			if(!count($file_array_2)) 
				$error2[] .= get_string('problemfilesolution',"assignment");

			if(count($file_array_1)) {
				echo "<div style='text-align: center; margin: 10px auto;'>\n";
				echo "<center>\n"; // nie je asi XHTML strict validne 
				echo "<table>\n";
				echo "<tr>\n";
				echo "\t<th style='padding: 3px 10px'>".get_string('assignment',"assignment")."</th>\n";
				echo "\t<th style='padding: 3px 10px'>".get_string('solution',"assignment")."</th>\n";
				echo "</tr>\n";
				foreach($file_array_1 as $value) {
					echo "<tr>\n";
					echo "\t<td style='text-align: left; padding: 3px 10px'><a href='".$CFG->wwwroot."/file.php/".$COURSE->id."/moddata/random/assignment/".$this->assignment->var1."/".$value."' target='_blank'>".$value."</a></td>\n";
					echo "\t<td style='text-align: left; padding: 3px 10px'>".((in_array($value,$file_array_2)) ? "<a href='".$CFG->wwwroot."/file.php/".$COURSE->id."/moddata/random/solution/".$this->assignment->var2."/".$value."' target='_blank'>".$value."</a>" : "")."</td>\n";
					echo "</tr>\n";
				}
				echo "</table>\n";
				echo "</center>\n"; // nie je asi XHTML strict validne 
				echo "</div>\n";
			}

			if($error1)
				echo "<p style='text-align: center; color: red; font-weight: bold;'>".implode("<br />", $error1)."</p>\n";
			if($error2)
				echo "<p style='text-align: center;'>".implode("<br />", $error2)."</p>\n";
		}
		else {
			if($this->assignment->var1) {
				// ak existuje adresar so zadaniami a sucasne nie je prihlaseny ucitel, potom bude zobrazene zadanie
				$fullpath = $CFG->dataroot.'/'.$COURSE->id.'/moddata/random/assignment/'.$this->assignment->var1;

				// zistenie uz priradenych suborov z vybraneho adresara
				$sql = "SELECT * FROM {$CFG->prefix}assignment_submissions WHERE assignment='".$this->assignment->id."'";
				$record = get_records_sql($sql);
				$file_array_db = array();
				foreach($record as $record_value)
					$file_array_db[] = $record_value->data1;

				// zistenie, ci je priradeny subor daneho zadania uzivatelovi 
				$sql_select = "SELECT * FROM {$CFG->prefix}assignment_submissions WHERE assignment='".$this->assignment->id."' AND userid='".$USER->id."'";
				$record = record_exists_sql($sql_select);

				// ak nie je priradeny subor, vyhlada volny a priradi ho (vlozenim do DB)
				if(!$record) {
					$file_array = array();
					$directory = opendir($fullpath); 
					while (false !== ($file = readdir($directory))) {
						if ($file == "." || $file == "..")
							continue;
						else
							$file_array[] = $file; // zoznam vsetkych suborov v adresari (vlozeny do pola)
					}
					closedir($directory);
					// ziskanie rozdielov poli suborov v DB a v adresari - vysledok je pole suborov, ktore este neboli priradene
					$file_array_diff = array_diff ($file_array, $file_array_db);
					if(count($file_array_diff)) {
						// ak nie je pole prazdne, potom vyber subor, ktory je prvym prvkom pola
						$keys = array_keys($file_array_diff); // kluce prvkov pola
						$file_select = $file_array_diff[$keys[0]];
					} 
					else {
						// ak je pole prazdne, t.j. vsetky subory uz boli priradene, potom sa priraduju subory nahodne
						// nahodny vyber prvku
						$item_random = intval(rand(0, count($file_array)-1));
						$file_select = $file_array[$item_random];
					}
					if($file_select) {
						$sql = "INSERT INTO ".$CFG->prefix."assignment_submissions (id, userid, assignment, data1, grade) VALUES (null,'".$USER->id."', '".$this->assignment->id."', '".$file_select."','-1')";
						execute_sql($sql, false); 
					}
				}

				$record = get_record_sql($sql_select);
				if($record->data1) {
					echo "<p style='text-align: center;'>".get_string('getassignment',"assignment","<a href='".$CFG->wwwroot."/file.php/".$COURSE->id."/moddata/random/assignment/".$this->assignment->var1."/".$record->data1."?random_submission=".$record->id."&amp;random_assignment=".$record->assignment."' target='_blank'>".get_string('getassignmenttext',"assignment")."</a>")."</p>\n";
					$url = $CFG->dataroot.'/'.$COURSE->id.'/moddata/random/assignment/'.$this->assignment->var1."/".$record->data1;
				}

				// ak existuje subor a tento subor je typu html alebo htm, zobraz ho 
				if(file_exists($url)) {
					$ext = array_pop(explode('.', $url));
					if($ext == 'html' || $ext == 'htm') {
						echo "<div style='margin: 10px 14%; background: white; padding: 10px; border: 1px solid silver;'>\n";
						$data = file_get_contents($url);
						// odstrani vsetko od zaciatku po element <body .... > vratane
						$data = eregi_replace("^.*<body[^>]*>","",$data);
						// odstrani vsetko od elementu </body> zaciatku po koniec
						$data = eregi_replace("</body>.*","",$data);
						echo "\n".trim($data)."\n\n";
						echo "</div>\n";
					}
				}
			}
		}

		if(!$this->assignment->var1 && !has_capability('mod/assignment:grade', $context))
			echo "<p style='text-align: center; color: red;'>".get_string('problem',"assignment")."</p>\n";

        $this->view_dates();


		if(!has_capability('mod/assignment:grade', $context)) {
			$filecount = $this->count_user_files($USER->id);

			if ($submission = $this->get_submission()) {
				if ($submission->timemarked) {
					$this->view_feedback();
				}
				if ($filecount) {
					print_simple_box($this->print_user_files($USER->id, true), 'center');
				}
			}

			if (has_capability('mod/assignment:submit', $context)  && $this->isopen() && (!$filecount || $this->assignment->resubmit || !$submission->timemarked)) {
				$this->view_upload_form();
			}
		}

        $this->view_footer();
    }

	// -----------------------------------------
	// Random assignment end
	// -----------------------------------------

    function view_upload_form() {
        global $CFG;
        $struploadafile = get_string("uploadafile");
        $strmaxsize = get_string("maxsize", "", display_size($this->assignment->maxbytes));

        echo '<div style="text-align:center">';
        echo '<form enctype="multipart/form-data" method="post" '.
             "action=\"$CFG->wwwroot/mod/assignment/upload.php\">";
        echo '<fieldset class="invisiblefieldset">';
        echo "<p>$struploadafile ($strmaxsize)</p>";
        echo '<input type="hidden" name="id" value="'.$this->cm->id.'" />';
        require_once($CFG->libdir.'/uploadlib.php');
        upload_print_form_fragment(1,array('newfile'),false,null,0,$this->assignment->maxbytes,false);
        echo '<input type="submit" name="save" value="'.get_string('uploadthisfile').'" />';
        echo '</fieldset>';
        echo '</form>';
        echo '</div>';
    }


    function upload() {
        global $CFG, $USER;
        
        require_capability('mod/assignment:submit', get_context_instance(CONTEXT_MODULE, $this->cm->id));

        $this->view_header(get_string('upload'));

        $filecount = $this->count_user_files($USER->id);
        $submission = $this->get_submission($USER->id);
        if ($this->isopen() && (!$filecount || $this->assignment->resubmit || !$submission->timemarked)) {
            if ($submission = $this->get_submission($USER->id)) {
                //TODO: change later to ">= 0", to prevent resubmission when graded 0
                if (($submission->grade > 0) and !$this->assignment->resubmit) {
                    notify(get_string('alreadygraded', 'assignment'));
                }
            }

            $dir = $this->file_area_name($USER->id);

            require_once($CFG->dirroot.'/lib/uploadlib.php');
            $um = new upload_manager('newfile',true,false,$this->course,false,$this->assignment->maxbytes);
            if ($um->process_file_uploads($dir)) {
                $newfile_name = $um->get_new_filename();
                if ($submission) {
                    $submission->timemodified = time();
                    $submission->numfiles     = 1;
                    $submission->submissioncomment = addslashes($submission->submissioncomment);
                    unset($submission->data1);  // Don't need to update this.
                    unset($submission->data2);  // Don't need to update this.
                    if (update_record("assignment_submissions", $submission)) {
                        add_to_log($this->course->id, 'assignment', 'upload', 
                                'view.php?a='.$this->assignment->id, $this->assignment->id, $this->cm->id);
                        $this->email_teachers($submission);
                        print_heading(get_string('uploadedfile'));
                    } else {
                        notify(get_string("uploadfailnoupdate", "assignment"));
                    }
                } else {
                    $newsubmission = $this->prepare_new_submission($USER->id);
                    $newsubmission->timemodified = time();
                    $newsubmission->numfiles = 1;
                    if (insert_record('assignment_submissions', $newsubmission)) {
                        add_to_log($this->course->id, 'assignment', 'upload', 
                                'view.php?a='.$this->assignment->id, $this->assignment->id, $this->cm->id);
                        $this->email_teachers($newsubmission);
                        print_heading(get_string('uploadedfile'));
                    } else {
                        notify(get_string("uploadnotregistered", "assignment", $newfile_name) );
                    }
                }
            }
        } else {
            notify(get_string("uploaderror", "assignment")); //submitting not allowed!
        }

       print_continue('view.php?id='.$this->cm->id);

        $this->view_footer();
    }

    function setup_elements(&$mform) {
        global $CFG, $COURSE;

        $ynoptions = array( 0 => get_string('no'), 1 => get_string('yes'));

        $mform->addElement('select', 'resubmit', get_string("allowresubmit", "assignment"), $ynoptions);
        $mform->setHelpButton('resubmit', array('resubmit', get_string('allowresubmit', 'assignment'), 'assignment'));
        $mform->setDefault('resubmit', 0);

        $mform->addElement('select', 'emailteachers', get_string("emailteachers", "assignment"), $ynoptions);
        $mform->setHelpButton('emailteachers', array('emailteachers', get_string('emailteachers', 'assignment'), 'assignment'));
        $mform->setDefault('emailteachers', 0);

        $choices = get_max_upload_sizes($CFG->maxbytes, $COURSE->maxbytes);
        $choices[0] = get_string('courseuploadlimit') . ' ('.display_size($COURSE->maxbytes).')';
        $mform->addElement('select', 'maxbytes', get_string('maximumsize', 'assignment'), $choices);
        $mform->setDefault('maxbytes', $CFG->assignment_maxbytes);

		// -------------------------------------------
        	// Random assignment begin
		// -------------------------------------------


		$mform->addElement('static', 'statictype', '', get_string('directoryassignmenthlptext','assignment'));
        $rawdirs = get_directory_list($CFG->dataroot.'/'.$COURSE->id.'/moddata/random/assignment', array($CFG->moddata, 'backupdata'), true, true, false);
        $dirs = array();
        $dirs[0] = get_string('maindirectoryassignment', 'assignment');
		foreach ($rawdirs as $rawdir) {
			// kontrola, ci je adresar  s ciselnym nazvom (cislo adresara musi byt preto, lebo databaza ma volne iba ciselne prvky)
			if(strlen(intval($rawdir)) == strlen($rawdir) && intval($rawdir))
        	    $dirs[$rawdir] = $rawdir;
        }
		// prvok formulara, ktorym sa vybera adresar so zadaniami
        $mform->addElement('select', 'var1', get_string("directoryassignment", "assignment"), $dirs);
        $mform->setHelpButton('var1', array('directoryassignmenthlp', get_string('directoryassignmenthlp', 'assignment'), 'assignment'));
        $mform->addRule('var1', get_string('required'), 'required', null, 'client');
        $mform->setDefault('windowpopup', 0);

		$mform->addElement('static', 'statictype', '', get_string('directorysolutionhlptext','assignment'));
        $rawdirs = get_directory_list($CFG->dataroot.'/'.$COURSE->id.'/moddata/random/solution', array($CFG->moddata, 'backupdata'), true, true, false);
        $dirs = array();
		$dirs[0] = get_string('maindirectorysolution', 'assignment');
        foreach ($rawdirs as $rawdir) {
			// kontrola, ci je adresar  s ciselnym nazvom (cislo adresara musi byt preto, lebo databaza ma volne iba ciselne prvky)
			if(strlen(intval($rawdir)) == strlen($rawdir) && intval($rawdir))
        	    $dirs[$rawdir] = $rawdir;
        }
		// prvok formulara, ktorym sa vybera adresar s rieseniami
        $mform->addElement('select', 'var2', get_string("directorysolution", "assignment"), $dirs);
        $mform->setHelpButton('var2', array('directorysolutionhlp', get_string('directorysolutionhlp', 'assignment'), 'assignment'));
        $mform->setDefault('windowpopup', 0);

		// -----------------------------------------
	        // Random assignment end
		// -----------------------------------------
    }
}

?>
