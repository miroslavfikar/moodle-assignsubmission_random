<?php
$string['inputfiles'] = 'Súbory zadaní';
$string['inputfiles_help'] = 'Súbory so zadaniami môžete prikladať buď po jednom súbore, alebo pri väčšom množstve si ich predtým zozipujte a po pridaní spätne odzipujete. Potom však zazipovaný súbor vymažte!<br />Ak k zadaniam existujú aj riešenia, potom súbory so zadaniami musia mať rovnaký názov ako súbory s riešeniami.';
$string['outputfiles'] = 'Súbory riešení';
$string['outputfiles_help'] = 'Súbory s riešeniami môžete prikladať buď po jednom súbore, alebo pri väčšom množstve si ich predtým zozipujte a po pridaní spätne odzipujete. Potom však zazipovaný súbor vymažte!<br />Súbory s riešeniami musia mať rovnaký názov ako súbory so zadaniami.';
$string['getassignment'] = 'Zadanie si môžete stiahnuť {$a}.';
$string['getassignmenttext'] = 'na tomto mieste';
$string['responsefilesassignment'] = 'Súbor so zadaním: ';
$string['responsefilessolution'] = 'Súbor s riešením: ';
$string['typerandom'] = 'Náhodné zadanie';
$string['assignments'] = 'Zadania';
$string['solutions'] = 'Riešenia';
$string['assignment'] = 'Zadanie';
$string['solution'] = 'Riešenie';
?>

