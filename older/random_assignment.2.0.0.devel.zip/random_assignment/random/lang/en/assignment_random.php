<?php
$string['inputfiles'] = 'Assignments files';
$string['inputfiles_help'] = 'Assignment files can be added ony by one or as a zip file. In the latter case unzip the file directly here and delete it afterwards. !<br />If there are solutions, the filenames have to match.';
$string['outputfiles'] = 'Solutions files';
$string['outputfiles_help'] = 'Solution files can be added ony by one
or as a zip file. In the latter case unzip the file directly here and delete it
afterwards. !<br />Solutions filenames  have to match with assignments.';
$string['getassignment'] = 'You can get the assignment {$a}.';
$string['getassignmenttext'] = 'here';
$string['responsefilesassignment'] = 'Assignment file: ';
$string['responsefilessolution'] = 'Solution file: ';
$string['typerandom'] = 'Random assignment';
$string['assignment'] = 'Assignments';
$string['solution'] = 'Solutions';
?>
