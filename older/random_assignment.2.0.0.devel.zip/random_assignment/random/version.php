<?php

$plugin->version = 2010031300;
$plugin->requires = 2010090501;

$submodule->version  = $plugin->version;
$submodule->requires = $plugin->requires;


?>