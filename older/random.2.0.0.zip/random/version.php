<?php

$plugin->version = 2011100901;
$plugin->requires = 2010112400;

$submodule->version  = $plugin->version;
$submodule->requires = $plugin->requires;

$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = "2.0.0 (20111009)"; // User-friendly version number
?>
