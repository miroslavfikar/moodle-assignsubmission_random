	// -------------------------------------------
	// Random assignment begin
	// -------------------------------------------

	if ((count($args) >= 4) and (strtolower($args[1]) == 'moddata') and (strtolower($args[2]) == 'random') and (strtolower($args[3]) == 'solution')) {
		// if the file requested is from directory moddata/random/solution test if we are teacher in the course
		if (!has_capability('mod/assignment:grade', get_context_instance(CONTEXT_COURSE, $course->id))) {
			// if not exit with error
			error('Access not allowed');
        } else {
            $lifetime = 0; //disable browser caching for backups 
        }
    }

	if ((count($args) >= 4) and (strtolower($args[1]) == 'moddata') and (strtolower($args[2]) == 'random')) {
		// if the file requested is from directory moddata/random/assignment test if we are teacher in the course or the student with this assignment
		$is_teacher = has_capability('mod/assignment:grade', get_context_instance(CONTEXT_COURSE, $course->id));
		$sql = "SELECT * FROM {$CFG->prefix}assignment_submissions WHERE id='".intval($_GET['random_submission'])."' AND assignment='".intval($_GET['random_assignment'])."' AND userid='".$USER->id."' AND data1='".$args[5]."'";
		$is_student_ok = record_exists_sql($sql);
		if (!$is_teacher and !$is_student_ok) {
			// no teacher, no student: error, exit
			error('Access not allowed');
        } else {
            $lifetime = 0; //disable browser caching for backups 
        }
    }

    // check that file exists
    if (!file_exists($pathname)) {
        not_found($course->id);
    }
    session_write_close(); // unlock session during fileserving
    $filename = $args[count($args)-1];
    send_file($pathname, $filename, $lifetime, $CFG->filteruploadedfiles, false, $forcedownload);
	// -----------------------------------------
	// Random assignment end
	// -----------------------------------------
