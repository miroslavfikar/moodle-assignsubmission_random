<?PHP 

$string['directoryassignment'] = 'Adresár so zadaniami';
$string['directoryassignmenthlp'] = 'Označte adresár v ktorom sa nachádzajú súbory daného zadania';
$string['directoryassignmenthlptext'] = '<span style=\'font-weight: bold\'>Poznámka:</span> aby ste mohli využívať náhodné prideľovanie súborov so zadaniami, musíte vytvoriť v danom kurze v adresári moddata adresár <span style=\'font-weight: bold\'>random</span>. Ak moddata ešte eexistuje, vytvorte ho. V adresári random vytvorte podadresáre <span style=\'font-weight: bold\'>assignment</span> a <span style=\'font-weight: bold\'>solution</span>. Adresár <span style=\'font-weight: bold\'>assignment</span> bude obsahovať podadresáre so zadaniami a adresár <span style=\'font-weight: bold\'>solution</span> bude obsahovať podadresáre s riešeniami, ktoré sú určené pre učiteľov. Podadresáre musia mať v názve iba číslo (napr. 10, t.j. stromová štruktúra od kurzu bude <span style=\'font-weight: bold\'>moddata/random/assignment/10</span>). Zadania aj riešenia musia mať rovnaký názov (nemusia byť umiestnené v adresároch s rovnakým názvom (napr. zadanie s názvom <span style=\'font-weight: bold\'> zad1.html </span> uložíme do <span style=\'font-weight: bold\'>moddata/random/assignment/10/zad1.html</span> a riešenie s rovnakým názvom <span style=\'font-weight: bold\'> zad1.html </span> uložíme do <span style=\'font-weight: bold\'>moddata/random/solutions/20/zad1.html</span>). Prepojenie zadaní a výsledkov urobíme výberom adresára so zadaniami (Adresár so zadaniami: <span style=\'font-weight: bold\'>10</span>) a adresára s výsledkami (Adresár s výsledkami: <span style=\'font-weight: bold\'>20</span>).';
$string['directorysolution'] = 'Adresár s výsledkami';
$string['directorysolutionhlp'] = 'Označte adresár v ktorom sa nachádzajú súbory s vypracovaním daného zadania';
$string['directorysolutionhlptext'] = 'Ak nie sú k dispozícii súbory s riešeniami, potom nie je potrebné nastavovať <span style=\'font-weight: bold\'>Adresár s výsledkami</span>.';  

$string['getassignment'] = 'Zadanie si môžete stiahnuť $a.';
$string['getassignmenttext'] = 'na tomto mieste';
$string['maindirectoryassignment'] = 'Vyberte adresár so zadaniami:';
$string['maindirectorysolution'] = 'Vyberte adresár s riešeniami:';
$string['problem'] = 'Zadania vo forme súborov zatiaľ nie sú k dispozícii!';
$string['problemdirectoryassignment'] = 'Nie je zvolený adresár so zadaniami!';
$string['problemdirectorysolution'] = 'Nie je zvolený adresár s riešeniami!';
$string['problemfileassignment'] = 'V adresári so zadaniami nie sú žiadne súbory!';
$string['problemfilesolution'] = 'V adresári s riešeniami nie sú žiadne súbory!';
$string['responsefilesassignment'] = 'Súbor so zadaním: $a';
$string['responsefilessolution'] = 'Súbor s riešením: $a';
$string['typerandom'] = 'Náhodné zadanie';

$string['assignment'] = 'Zadania';
$string['solution'] = 'Riešenia';
?>
