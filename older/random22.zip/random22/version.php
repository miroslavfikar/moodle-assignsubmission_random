<?php

$plugin->version = 2012083101;
$plugin->requires = 2010112400;

$submodule->version  = $plugin->version;
$submodule->requires = $plugin->requires;

$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = "2.0.4 (20120831)"; // User-friendly version number
?>
