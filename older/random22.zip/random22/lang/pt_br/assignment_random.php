<?php
// This file is part of Random Assignment plugin for Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Module language strings
 *
 * @package    assignment
 * @subpackage random
 * @copyright  2007-2011 Miroslav Fikar  {@link http://kirp.chtf.stuba.sk/~fikar}
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

$string['inputfiles'] = 'Arquivos com Tarefas';
$string['inputfiles_help'] = 'Arquivos com Tarefas podem ser adicionados um a um, ou através de um arquivo zip. No segundo caso, descompacte o arquivo diretamente aqui e depois apague-o. !<br /> Se há soluções, então o nome dos arquivos das tarefas devem ser identicos aos da solução.';
$string['outputfiles'] = 'Arquivos com Soluções';
$string['outputfiles_help'] = 'Arquivos com soluções podem ser adicionados um a um, ou através de um arquivo zip. No segundo caso, descompacte o arquivo diretamente aqui e depois apague-o. !<br /> Os nomes dos arquivos de solução devem ser identicos aos das tarefas.';
$string['getassignment'] = 'Você pode obter sua tarefa {$a}.';
$string['getassignmenttext'] = 'aqui';
$string['responsefilesassignment'] = 'Arquivo com Tarefa: ';
$string['responsefilessolution'] = 'Arquivo com Solução: ';
$string['typerandom'] = 'Tarefa Aleatória';
$string['assignments'] = 'Tarefas';
$string['solutions'] = 'Soluções';
$string['assignment'] = 'Tarefa';
$string['solution'] = 'Solução';
$string['pluginname'] = 'Tarefa Aleatória';

?>
