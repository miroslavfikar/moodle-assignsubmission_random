<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.


/**
 * Strings for component 'assignsubmission_random', language 'en'
 *
 * @package   assignsubmission_random
 * @copyright 2012 KIRP FCHPT STU in Bratislava {@link http://kirp.chtf.stuba.sk}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['enabled'] = 'Povoliť náhodné zadania'; 
$string['enabled_help'] = 'Ak sú náhodné zadania povolené, pridajte súbory zadaní nižšie. Ak potrebujete, pridajte aj súbory s riešeniami, ktoré budú mať rovnaké názvy. Každý študent dostane náhodne jedno zo zadaní. Učiteľ vidí u každého študenta, ktoré zadanie dostal. Ak existujú súbory s riešeniami, vidí učiteľ aj zodpovedaj[ce riešenie'; 
$string['inputfiles'] = 'Náhodné zadanie - súbory zadaní';
$string['inputfiles_help'] = 'Vložte súbory, z ktorých dostane každý študent jedno náhodne. ';
$string['outputfiles'] = 'Náhodné zadanie - súbory riešení';
$string['outputfiles_help'] = 'Vložte súbory s riešeniami s rovnakými názvami, ako v súboroch zadaní';
$string['getassignment'] = 'Zadanie si môžete stiahnuť {$a}.';
$string['getassignmenttext'] = 'na tomto mieste';
$string['responsefilesassignment'] = 'Súbor so zadaním: ';
$string['responsefilessolution'] = 'Súbor s riešením: ';
$string['typerandom'] = 'Náhodné zadanie';
$string['assignments'] = 'Zadania';
$string['solutions'] = 'Riešenia';
$string['assignment'] = 'Zadanie';
$string['solution'] = 'Riešenie';
$string['pluginname'] = 'Náhodné zadanie';