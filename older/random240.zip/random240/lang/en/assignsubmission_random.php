<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.


/**
 * Strings for component 'assignsubmission_random', language 'en'
 *
 * @package   assignsubmission_random
 * @copyright 2012 KIRP FCHPT STU in Bratislava {@link http://kirp.chtf.stuba.sk}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['enabled'] = 'Enable random assignments'; 
$string['enabled_help'] = 'If random assignment is enabled then add files to below to random assignment files and solutions. Each students will get one of files randomly. If there are solution files with the same names, teacher will see the corresponding solution file'; 
$string['inputfiles'] = 'Random assignment - assignments files';
$string['inputfiles_help'] = 'Add files that will be randomly distributed to students.';
$string['outputfiles'] = 'Random assignment - solution files';
$string['outputfiles_help'] = 'Add solution files with matching names to random assignment files.';
$string['getassignment'] = 'You can get the assignment {$a}.';
$string['getassignmenttext'] = 'here';
$string['responsefilesassignment'] = 'Assignment file: ';
$string['responsefilessolution'] = 'Solution file: ';
$string['typerandom'] = 'Random assignment';
$string['assignments'] = 'Assignments';
$string['solutions'] = 'Solutions';
$string['assignment'] = 'Assignment';
$string['solution'] = 'Solution';
$string['pluginname'] = 'Random assignment';