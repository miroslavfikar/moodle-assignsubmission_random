Random assignment (implemented for Moodle 1.8.2, tested with 1.9.2)

Random assignment is an attempt to handle larger classes of students.
For this purpose, we generate a series of html or pdf files with the
same structure but different numbers. In addition, we generate
corresponding files with hints to solutions for teachers.

Random assignment is a plugin for assignments with following
properties:

- Teacher specifies a directory containing one or more files for
  assignments and (optionally) a directory with solutions

- Each student gets one of these files randomly 

- In the assignment feedback page, teacher sees the assignment file
  and optionally the solution file as well.

The following structure of directories must be created in the course area

/moddata/random
/moddata/random/assignment
/moddata/random/solution

The assignments and solutions are then stored in subdirectories of these
directories with numerical names (that need not be the same), for example

/moddata/random/assignment/10
/moddata/random/solution/20

We can for example have

/moddata/random/assignment/10/file1.html
/moddata/random/assignment/10/otherfile.html
/moddata/random/assignment/10/file2.pdf
/moddata/random/assignment/10/file-without-solution.doc

and (if needed)

/moddata/random/solution/20/file1.html
/moddata/random/solution/20/otherfile.html
/moddata/random/solution/20/file2.pdf


Installation procedure:

1. Copy directory random/ to moodle/mod/assignment/type/
2. Copy directory lang/ to moodledata/. Language files are stored in
   _local directories and thus do not interfere with standard
   assignment.php language files. 
3. Optionally, for better security, add the content in file.php (file.part.php)
   regarding random assignment to the corresponding place in
   moodle/file.php (otherwise, students can guess the solution
   directory name and then they can read the solution directly 
   from server). Only if there are solutions or if you do not want
   students guess other students files.

Preparation for assignments:

1. In the files area check whether directory 'moddata' exists. If not, create it.
2. In the directory moddata, create directory 'random'.
3. In the directory random, create two directories: 'assignment' and 'solution'.

Creation of an assignment:

1. Create a directory with numerical name in directory 'assignment'. 
   Numerical name can be for example 1, 2, 10, 300, ...
2. Copy files with assignments to this directory.
3. Optionally, create a directory in directory 'solution' with numerical name and
   copy the files with the same names as before. These contain solutions or hints 
   to solutions for teachers. 
4. Create activity: random assignment and specify directories for assignments and solutions.

Student sees link to the assignment and, optionally its content if it is a html file.
Teacher sees links to both files when grading a student on the feedback page. Teacher also sees
links to all files on the assignment page.

Backup and restore:

The random assignment files are stored in userdata area of backups.
In the case that the course is backupped or restored without user
data, the files are not preserved. Therefore, it is always advisable to
zip the whole moddata/random directory at the server outside moddata
directory and not accessible to students. If the course is restored
without used data (for example in preparation for a new semester), it
will afterwards be very easy to restore the directory structure from
the zip file.

miroslav.fikar[at]gmail.com
lubos.cirka[at]stuba.sk
August 2007

Citation:
@inproceedings{vu2007,
  author 	 =  	{Cirka, L. and Fikar, M.},
  title 	 =  	{LMS Moodle - Random Assignment},
  booktitle 	 =  	{Proc. of 8th International Conference Virtual university 2007},
  year 	 =  	{2007},
  pages 	 =  	{168-170},
  editor 	 =  	{Huba, M.},
  address 	 =  	{Bratislava},
  month 	 =  	{December 13 - 14},
  annote 	 =  	{The aim of this paper is to describe the new assignment type - random assignment. The plugin Random text for module Assignment is a Moodle activity add-on for uploads to each assignment several files for students and possibly files for instructors with solutions.}
}

<a href="http://www.kirp.chtf.stuba.sk/publicatione_info.php?id_pub=433">Full paper [PDF]</a>
