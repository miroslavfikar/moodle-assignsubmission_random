<?PHP // $Id: assignment.php,v 1.12 2006/11/20 16:56:39 skodak Exp $ 
      // assignment.php - created with Moodle 1.7 beta + (2006101003)

$string['directoryassignment'] = 'Directory with assignments';
$string['directoryassignmenthlp'] = 'Choose directory with assignments';
$string['directoryassignmenthlptext'] = '<span style=\'font-weight: bold\'>Note:</span> Random assignemnt need the following fixed directory structure: in the main course directory, there exist a directory moddata. If not, create it. Then in moddata, create directory <span style=\'font-weight: bold\'>random</span>. Within this directory, create two directories <span style=\'font-weight: bold\'>assignment</span> and <span style=\'font-weight: bold\'>solution</span>. The directory <span style=\'font-weight: bold\'>assignment</span> will contain directories with assignments and directory <span style=\'font-weight: bold\'>solution</span> will contain directories with solutions. Subdirectory names can only be numeric (for example.g. 10, e.g. the directory structure will be  <span style=\'font-weight: bold\'>moddata/random/assignment/10</span>). Assignment and solution directories need not have the same name (for example assignment with name  <span style=\'font-weight: bold\'>assign1.html </span> can be in directory <span style=\'font-weight: bold\'>moddata/random/assignment/10/assign1.html</span> and solution with the same name <span style=\'font-weight: bold\'>assign1.html </span> can be located in <span style=\'font-weight: bold\'>moddata/random/solutions/20/assign1.html</span>). Connection between assignemnts and solutions is specified by the selection of two directories for asignment (assignment directory: <span style=\'font-weight: bold\'>10</span>) and solution (solution directory: <span style=\'font-weight: bold\'>20</span>).';
$string['directorysolution'] = 'Directory with solutions';
$string['directorysolutionhlp'] = 'Choose directory with solutions';
$string['directorysolutionhlptext'] = 'It is not necessary to choose the <span style=\'font-weight: bold\'>solution directory</span> if there are no solutions available.';  
$string['getassignment'] = 'You can get the assignment $a.';
$string['getassignmenttext'] = 'here';
$string['maindirectoryassignment'] = 'Choose directory with assignments:';
$string['maindirectorysolution'] = 'Choose directory with solutions:';
$string['problem'] = 'Files with assignments are not yet disponible!';
$string['problemdirectoryassignment'] = 'Assignment directory is not chosen!';
$string['problemdirectorysolution'] = 'Solution directory is not chosen!';
$string['problemfileassignment'] = 'Assignment directory does not contain any files!';
$string['problemfilesolution'] = 'Solution directory does not contain any files!';
$string['responsefilesassignment'] = 'Assignment file: $a';
$string['responsefilessolution'] = 'Solution file: $a';
$string['typerandom'] = 'Random assignment';
$string['assignment'] = 'Assignments';
$string['solution'] = 'Solutions';
?>
